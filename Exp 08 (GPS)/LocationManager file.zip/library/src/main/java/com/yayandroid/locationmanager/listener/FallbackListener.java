package com.yayandroid.locationmanager.listener;

public interface FallbackListener {
    void onFallback();
}